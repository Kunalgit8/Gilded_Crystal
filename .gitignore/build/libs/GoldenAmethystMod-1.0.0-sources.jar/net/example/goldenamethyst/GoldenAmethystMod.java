package net.example.goldenamethyst;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3719;
import net.minecraft.class_7923;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GoldenAmethystMod implements ModInitializer {

    public static final String MOD_ID = "goldenamethyst";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // ── Item Registration ──────────────────────────────────────────────────────
    public static final class_1792 GOLDEN_AMETHYST = new class_1792(new class_1792.class_1793().method_7889(16));

    @Override
    public void onInitialize() {
        // Register the item
        class_2378.method_10230(
                class_7923.field_41178,
                class_2960.method_60655(MOD_ID, "golden_amethyst"),
                GOLDEN_AMETHYST
        );

        LOGGER.info("GoldenAmethystMod initialised!");

        // ── Feature 1 & 2: UseItemCallback (right-click air) ──────────────────
        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 stack = player.method_5998(hand);
            if (!stack.method_31574(GOLDEN_AMETHYST)) return class_1271.method_22430(stack);

            // Feature 1 – Kinetic Blink (dash): sneak + airborne + right-click air
            if (player.method_5715() && !player.method_24828()) {
                if (!world.field_9236) {
                    class_243 look = player.method_5828(1.0f);
                    player.method_18799(look.method_1021(1.5));
                    player.field_6037 = true;
                    stack.method_7934(1);
                    player.method_7353(class_2561.method_43470("§6Kinetic Blink!"), true);
                }
                return class_1271.method_22427(stack);
            }
            return class_1271.method_22430(stack);
        });

        // ── Feature 2: UseBlockCallback (right-click block) ───────────────────
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            class_1799 stack = player.method_5998(hand);
            if (!stack.method_31574(GOLDEN_AMETHYST)) return class_1269.field_5811;

            // Cooldown check (200 ticks = 10 s)
            if (player.method_7357().method_7904(GOLDEN_AMETHYST)) {
                player.method_7353(class_2561.method_43470("§cTreasure Sense is cooling down!"), true);
                return class_1269.field_5814;
            }

            if (!world.field_9236) {
                class_3218 serverWorld = (class_3218) world;
                class_2338 origin = player.method_24515();
                boolean found = false;

                for (class_2338 pos : class_2338.method_10097(
                        origin.method_10069(-10, -10, -10),
                        origin.method_10069(10, 10, 10))) {

                    class_2586 be = world.method_8321(pos);
                    if (be instanceof class_2595 || be instanceof class_3719) {
                        found = true;
                        class_243 target = class_243.method_24953(pos);
                        class_243 start  = player.method_33571();

                        // Spawn WAX_OFF particles along the line toward each container
                        for (int i = 1; i <= 10; i++) {
                            double t = i / 10.0;
                            double px = start.field_1352 + (target.field_1352 - start.field_1352) * t;
                            double py = start.field_1351 + (target.field_1351 - start.field_1351) * t;
                            double pz = start.field_1350 + (target.field_1350 - start.field_1350) * t;
                            serverWorld.method_14199(
                                    class_2398.field_29643,
                                    px, py, pz,
                                    1, 0, 0, 0, 0.05
                            );
                        }
                    }
                }

                if (found) {
                    player.method_7353(class_2561.method_43470("§aTreasure Sense: containers nearby!"), true);
                } else {
                    player.method_7353(class_2561.method_43470("§7No containers found within 10 blocks."), true);
                }

                // Apply 10-second cooldown
                player.method_7357().method_7906(GOLDEN_AMETHYST, 200);
            }
            return class_1269.field_5812;
        });

        // ── Feature 3: Stasis Strike ───────────────────────────────────────────
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            class_1799 stack = player.method_5998(hand);
            if (!stack.method_31574(GOLDEN_AMETHYST)) return class_1269.field_5811;

            if (entity instanceof class_1309 living && !world.field_9236) {
                // Slowness X + Weakness X for 4 seconds (80 ticks), amplifier 9 = level X
                living.method_6092(new class_1293(class_1294.field_5909,  80, 9));
                living.method_6092(new class_1293(class_1294.field_5911,  80, 9));
                stack.method_7934(1);
                player.method_7353(class_2561.method_43470("§9Stasis Strike!"), true);
            }
            return class_1269.field_5811; // PASS so the normal hit still registers
        });
    }
}