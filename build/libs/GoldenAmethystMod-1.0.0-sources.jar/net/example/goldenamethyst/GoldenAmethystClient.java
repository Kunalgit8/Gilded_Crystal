package net.example.goldenamethyst;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_5498;
import net.minecraft.class_638;

public class GoldenAmethystClient implements ClientModInitializer {

    public static boolean cutscenePlaying = false;
    public static int cutsceneTick = 0;
    public static final int CUTSCENE_DURATION = 160;
    public static boolean hasSeenCutscene = false;

    private static double playerX = 0;
    private static double playerY = 0;
    private static double playerZ = 0;
    private static float playerYaw = 0;
    private static class_5498 originalPerspective;
    public static float domainCharge = 0f;
    public static boolean domainCharging = false;
    private static final int CHARGE_TICKS = 60;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1687 == null || client.field_1724 == null) return;

            class_638 world = client.field_1687;
            class_1661 inv = client.field_1724.method_31548();

            for (int i = 0; i < inv.method_5439(); i++) {
                class_1799 stack = inv.method_5438(i);
                if (stack.method_31574(GoldenAmethystMod.VOID_CRYSTAL)) {
                    if (i == inv.field_7545) {
                        class_243 pos = client.field_1724.method_19538();
                        world.method_8406(
                                class_2398.field_11216,
                                pos.field_1352 + (Math.random() - 0.5) * 0.1,
                                pos.field_1351 + 0.3 + (Math.random() * 0.2),
                                pos.field_1350 + (Math.random() - 0.5) * 0.1,
                                (Math.random() - 0.5) * 0.01,
                                Math.random() * 0.02,
                                (Math.random() - 0.5) * 0.01
                        );
                    }
                }
            }
            class_310 mc = client;
            if (mc.field_1724 != null) {
                class_1799 held = mc.field_1724.method_6047();
                boolean holdingCrystal = held.method_31574(GoldenAmethystMod.VOID_CRYSTAL);
                boolean pressing = holdingCrystal && mc.field_1690.field_1904.method_1434();

                if (pressing) {
                    domainCharging = true;
                    domainCharge = Math.min(domainCharge + 1f / CHARGE_TICKS, 1f);
                    if (domainCharge >= 1f) {
                        domainCharge = 0f;
                        domainCharging = false;
                        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(
                                new GoldenAmethystMod.ActivateDomainPayload()
                        );
                    }
                } else {
                    domainCharge = Math.max(domainCharge - 0.05f, 0f);
                    if (domainCharge == 0f) domainCharging = false;
                }
            }

            if (!cutscenePlaying) return;
            cutsceneTick++;

            if (cutsceneTick == 1) {
                playerX = client.field_1724.method_23317();
                playerY = client.field_1724.method_23318();
                playerZ = client.field_1724.method_23321();
                playerYaw = client.field_1724.method_36454();
                originalPerspective = client.field_1690.method_31044();
                client.field_1724.method_5783(class_3417.field_14671, 1.0f, 1.0f);
                client.field_1690.method_31043(class_5498.field_26665);
                client.field_1724.method_36457(-90f);
                client.field_1724.method_18800(0, 0, 0);
            }
            if (cutsceneTick >= 61 && cutsceneTick <= 140) {
                double progress = (cutsceneTick - 61) / 79.0;
                double eased = progress * progress;
                float pitch = (float) (-90f + 180f * eased);
                client.field_1724.method_36457(pitch);
                client.field_1724.method_18800(0, 0, 0);
            }

            // End cutscene
            if (cutsceneTick >= CUTSCENE_DURATION) {
                cutscenePlaying = false;
                cutsceneTick = 0;
                client.field_1690.method_31043(originalPerspective);
                client.field_1724.method_36457(0f);
                client.field_1724.method_36456(playerYaw);
            }
        });
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            if (!cutscenePlaying) return;

            class_310 client = class_310.method_1551();
            int screenW = client.method_22683().method_4486();
            int screenH = client.method_22683().method_4502();

            if (cutsceneTick <= 60) {
                drawContext.method_25294(0, 0, screenW, screenH, 0xDD1A0033);

                String title = "§5§lThe Void Shard Captured";
                drawContext.method_51433(client.field_1772, title,
                        (screenW - client.field_1772.method_1727(title)) / 2,
                        screenH / 2 - 60, 0xFFCC99FF, true);

                String line1 = "§oA fragment of an ancient presence, split and bound";
                drawContext.method_51433(client.field_1772, line1,
                        (screenW - client.field_1772.method_1727(line1)) / 2,
                        screenH / 2 - 30, 0xFFAA88CC, true);

                String line2 = "§oin glass by the hands of forgotten gods.";
                drawContext.method_51433(client.field_1772, line2,
                        (screenW - client.field_1772.method_1727(line2)) / 2,
                        screenH / 2 - 18, 0xFFAA88CC, true);

                String line3 = "§oUnbound by time, it waits. Neither dead. Nor sleeping.";
                drawContext.method_51433(client.field_1772, line3,
                        (screenW - client.field_1772.method_1727(line3)) / 2,
                        screenH / 2, 0xFFAA88CC, true);

                String line4 = "§oYou hold a shard of a sundered master.";
                drawContext.method_51433(client.field_1772, line4,
                        (screenW - client.field_1772.method_1727(line4)) / 2,
                        screenH / 2 + 18, 0xFFAA88CC, true);

                String warn = "§4§lThe glass is thin. Do not let it shatter.";
                drawContext.method_51433(client.field_1772, warn,
                        (screenW - client.field_1772.method_1727(warn)) / 2,
                        screenH / 2 + 45, 0xFFFF3333, true);
            }

            if (cutsceneTick > 60) {
                drawContext.method_25294(0, 0, screenW, screenH, 0x331A0033);
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null) return;
            if (!domainCharging && domainCharge == 0f) return;

            int screenW = client.method_22683().method_4486();
            int screenH = client.method_22683().method_4502();
            int cx = screenW / 2;
            int cy = screenH / 2 + 40;

            int radius = 30;
            int segments = 64;
            float angle = domainCharge * 360f;

            drawContext.method_25294(cx - radius - 2, cy - radius - 2, cx + radius + 2, cy + radius + 2, 0x88000000);

            for (int i = 0; i < segments; i++) {
                float segAngle = (i / (float) segments) * 360f;
                if (segAngle > angle) break;

                float rad = (float) Math.toRadians(segAngle - 90f);
                int x1 = (int) (cx + Math.cos(rad) * (radius - 4));
                int y1 = (int) (cy + Math.sin(rad) * (radius - 4));
                int x2 = (int) (cx + Math.cos(rad) * radius);
                int y2 = (int) (cy + Math.sin(rad) * radius);

                int r = (int) (80 + 120 * domainCharge);
                int g = 0;
                int b = (int) (180 + 75 * domainCharge);
                int color = 0xFF000000 | (r << 16) | (g << 8) | b;

                drawContext.method_25294(Math.min(x1, x2), Math.min(y1, y2),
                        Math.max(x1, x2) + 2, Math.max(y1, y2) + 2, color);
            }

            drawContext.method_25294(cx - 4, cy - 4, cx + 4, cy + 4, 0xFF1A0033);
            drawContext.method_25294(cx - 2, cy - 2, cx + 2, cy + 2,
                    domainCharge >= 1f ? 0xFFCC99FF : 0xFF6600AA);

            String label = domainCharge >= 0.99f ? "§5§lVOID REALM" : "§5Charging...";
            int lw = client.field_1772.method_1727(label);
            drawContext.method_51433(client.field_1772, label, cx - lw / 2, cy + radius + 6, 0xFFCC99FF, true);
        });
        ClientPlayNetworking.registerGlobalReceiver(
                GoldenAmethystMod.StartCutscenePayload.ID,
                (payload, context) -> {
                    context.client().execute(GoldenAmethystClient::startCutscene);
                }
        );
    }

    public static void startCutscene() {
        cutscenePlaying = true;
        cutsceneTick = 0;
    }
}