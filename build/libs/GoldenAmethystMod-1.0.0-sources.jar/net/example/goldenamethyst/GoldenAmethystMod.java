package net.example.goldenamethyst;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3719;
import net.minecraft.class_7923;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.ArrayDeque;
import java.util.Deque;

public class GoldenAmethystMod implements ModInitializer {

    public static final String MOD_ID = "goldenamethyst";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_1792 GOLDEN_AMETHYST = new class_1792(new class_1792.class_1793().method_7889(16));
    public static final class_1792 VOID_ESSENCE = new class_1792(new class_1792.class_1793().method_7889(1));
    public static final class_1792 VOID_CRYSTAL = new class_1792(new class_1792.class_1793().method_7889(16));
    public static final Map<class_2338, Integer> VOID_PORTALS = new HashMap<>();
    public static final Set<UUID> DRAGON_DROPPED = new HashSet<>();
    public static final class_2960 START_CUTSCENE_PACKET = class_2960.method_60655(MOD_ID, "start_cutscene");
    public static final Deque<PlayerSnapshot> snapshots = new ArrayDeque<>();
    public static int recount = 0;
    private static long rewstart = 0;
    private static final java.util.Set<UUID> sneakDropping = new java.util.HashSet<>();
    public static final Map<UUID, Long> domainCooldowns = new HashMap<>();
    public static final Map<UUID, java.util.List<class_2338>> activeDomes = new HashMap<>();
    public static final Map<UUID, Integer> domainTicks = new HashMap<>();

    private static class PlayerSnapshot {
        final double x, y, z;
        final float health;
        final int food;
        final float saturation;
        final java.util.List<class_1293> effects;
        final long time;
        PlayerSnapshot(double x, double y, double z, float health, int food, float saturation, java.util.List<class_1293> effects, long time) {
            this.x = x; this.y = y; this.z = z;
            this.health = health; this.food = food; this.saturation = saturation;
            this.effects = effects; this.time = time;
        }
    }

    @Override
    public void onInitialize() {
        net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry.playS2C()
                .register(StartCutscenePayload.ID, StartCutscenePayload.CODEC);
        net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry.playC2S()
                .register(ActivateDomainPayload.ID, ActivateDomainPayload.CODEC);

        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "golden_amethyst"), GOLDEN_AMETHYST);
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "void_essence"), VOID_ESSENCE);
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "void_crystal"), VOID_CRYSTAL);
        LOGGER.info("GoldenAmethystMod initialised!");

        // Domain tick handler
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3218 world : server.method_3738()) {
                for (net.minecraft.class_3222 player : world.method_18456()) {
                    UUID uid = player.method_5667();
                    if (!domainTicks.containsKey(uid)) continue;

                    int tick = domainTicks.get(uid);
                    domainTicks.put(uid, tick + 1);

                    net.minecraft.class_238 box = new net.minecraft.class_238(
                            player.method_23317() - 15, player.method_23318() - 15, player.method_23321() - 15,
                            player.method_23317() + 15, player.method_23318() + 15, player.method_23321() + 15);

                    java.util.List<class_1309> mobs = world.method_8390(
                            class_1309.class, box,
                            e -> !(e instanceof net.minecraft.class_1657));

                    for (class_1309 mob : mobs) {
                        double dx = mob.method_23317() - player.method_23317();
                        double dy = mob.method_23318() - player.method_23318();
                        double dz = mob.method_23321() - player.method_23321();
                        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                        if (dist > 14.5) {
                            mob.method_18800(-(dx / dist) * 0.5, -(dy / dist) * 0.3, -(dz / dist) * 0.5);
                            mob.field_6037 = true;
                        }
                    }

                    if (tick % 20 == 0) {
                        for (class_1309 damaged : mobs) {
                            damaged.method_5643(world.method_48963().method_48831(), 2.0f);
                            damaged.method_6092(new class_1293(class_1294.field_5920, 40, 1));
                            damaged.method_6092(new class_1293(class_1294.field_5909, 40, 3));
                        }
                        world.method_14199(class_2398.field_11216, player.method_23317(), player.method_23318() + 1, player.method_23321(), 30, 10, 5, 10, 0.05);
                        world.method_14199(class_2398.field_11214, player.method_23317(), player.method_23318() + 1, player.method_23321(), 30, 10, 5, 10, 0.1);
                    }

                    boolean allDead = mobs.isEmpty();
                    boolean expired = tick >= 1800;

                    if (allDead || expired) {
                        if (activeDomes.containsKey(uid)) {
                            for (class_2338 bp : activeDomes.get(uid)) {
                                world.method_8501(bp, net.minecraft.class_2246.field_10124.method_9564());
                            }
                            activeDomes.remove(uid);
                        }
                        domainTicks.remove(uid);
                        domainCooldowns.put(uid, System.currentTimeMillis());
                        player.method_7353(class_2561.method_43470("§5The domain collapses..."), true);
                    }
                }
            }
        });

        // Snapshot recorder
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3218 world : server.method_3738()) {
                for (net.minecraft.class_3222 player : world.method_18456()) {
                    long now = System.currentTimeMillis();
                    snapshots.addLast(new PlayerSnapshot(
                            player.method_23317(), player.method_23318(), player.method_23321(),
                            player.method_6032(),
                            player.method_7344().method_7586(),
                            player.method_7344().method_7589(),
                            new java.util.ArrayList<>(player.method_6026()),
                            now));
                    while (!snapshots.isEmpty() && now - snapshots.peekFirst().time > 3000) {
                        snapshots.pollFirst();
                    }
                }
            }
        });

        net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> true);

        // Rewind handler
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3218 world : server.method_3738()) {
                for (net.minecraft.class_3222 player : world.method_18456()) {
                    class_1799 held = player.method_6047();
                    if (!held.method_31574(VOID_CRYSTAL)) continue;
                    if (!player.method_5715()) continue;

                    net.minecraft.class_238 box = new net.minecraft.class_238(player.method_24515()).method_1014(2.0);
                    java.util.List<net.minecraft.class_1542> dropped =
                            world.method_18023(net.minecraft.class_1299.field_6052, box,
                                    e -> e.method_6983().method_31574(VOID_CRYSTAL) && e.field_6012 < 2);

                    if (!dropped.isEmpty() && !sneakDropping.contains(player.method_5667())) {
                        sneakDropping.add(player.method_5667());

                        for (net.minecraft.class_1542 ie : dropped) {
                            player.method_31548().method_7398(ie.method_6983());
                            ie.method_31472();
                        }

                        long now = System.currentTimeMillis();
                        if (player.method_7357().method_7904(VOID_CRYSTAL)) {
                            player.method_7353(class_2561.method_43470("§cbro is NOT the void master"), true);
                            continue;
                        }
                        if (now - rewstart > 60000) { rewstart = now; recount = 0; }
                        recount++;
                        if (recount >= 5) {
                            player.method_7357().method_7906(VOID_CRYSTAL, 1200);
                            recount = 0;
                            continue;
                        }
                        if (!snapshots.isEmpty()) {
                            PlayerSnapshot snap = snapshots.peekFirst();
                            player.method_14251((class_3218) world, snap.x, snap.y, snap.z, player.method_36454(), player.method_36455());
                            player.method_6033(snap.health);
                            player.method_7344().method_7580(snap.food);
                            player.method_7344().method_7581(snap.saturation);
                            player.method_20803(0);
                            player.method_6012();
                            for (class_1293 effect : snap.effects) {
                                player.method_6092(new class_1293(effect));
                            }
                            held.method_7934(1);
                            player.method_7353(class_2561.method_43470("§5Time flows backwards..."), true);
                        } else {
                            player.method_7353(class_2561.method_43470("§cNo moment to return to."), true);
                        }
                    } else {
                        sneakDropping.remove(player.method_5667());
                    }
                }
            }
        });

        // Void floor handler
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3218 world : server.method_3738()) {
                for (net.minecraft.class_3222 player : world.method_18456()) {
                    boolean hasVoidCrystal = false;
                    for (int i = 0; i < player.method_31548().method_5439(); i++) {
                        if (player.method_31548().method_5438(i).method_31574(VOID_CRYSTAL)) { hasVoidCrystal = true; break; }
                    }
                    if (hasVoidCrystal && player.method_23318() <= -68.0 && player.method_23318() >= -72.0 && player.method_18798().field_1351 < 0) {
                        player.method_18800(player.method_18798().field_1352, 0, player.method_18798().field_1350);
                        player.method_6082(player.method_23317(), -70.0, player.method_23321(), false);
                        player.field_6017 = 0;
                        player.field_6037 = true;
                    }
                }
            }
        });

        // Dragon Egg + Treasure Sense
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            class_2338 pos = hitResult.method_17777();

            if (world.method_8320(pos).method_27852(net.minecraft.class_2246.field_10081)) {
                if (!world.field_9236) {
                    int total = 0;
                    for (int i = 0; i < player.method_31548().method_5439(); i++) {
                        class_1799 s = player.method_31548().method_5438(i);
                        if (s.method_31574(GOLDEN_AMETHYST)) total += s.method_7947();
                    }
                    if (total == 0) {
                        player.method_7353(class_2561.method_43470("You don't have any Golden Amethyst yet, come back later"), true);
                        return class_1269.field_5814;
                    }
                    for (int i = 0; i < player.method_31548().method_5439(); i++) {
                        class_1799 s = player.method_31548().method_5438(i);
                        if (s.method_31574(GOLDEN_AMETHYST)) {
                            player.method_31548().method_5447(i, new class_1799(VOID_CRYSTAL, s.method_7947()));
                        }
                    }
                    if (world instanceof class_3218 sw) {
                        sw.method_14199(class_2398.field_11216, pos.method_10263() + 0.5, pos.method_10264() + 1, pos.method_10260() + 0.5, 100, 0.5, 0.5, 0.5, 0.1);
                        sw.method_14199(class_2398.field_11214, pos.method_10263() + 0.5, pos.method_10264() + 1, pos.method_10260() + 0.5, 100, 0.5, 0.5, 0.5, 0.2);
                    }
                    boolean firstTime = !player.method_5752().contains("void_awakened");
                    if (firstTime) {
                        player.method_5780("void_awakened");
                        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(
                                (net.minecraft.class_3222) player,
                                new StartCutscenePayload());
                    } else {
                        player.method_7353(class_2561.method_43470("§5Your crystals have been awakened by the void"), true);
                    }
                }
                return class_1269.field_5812;
            }

            class_1799 stack = player.method_5998(hand);
            if (!stack.method_31574(GOLDEN_AMETHYST) && !stack.method_31574(VOID_CRYSTAL)) return class_1269.field_5811;

            if (player.method_7357().method_7904(GOLDEN_AMETHYST) || player.method_7357().method_7904(VOID_CRYSTAL)) {
                player.method_7353(class_2561.method_43470("§cTreasure Sense is cooling down!"), true);
                return class_1269.field_5814;
            }

            if (!world.field_9236) {
                class_3218 serverWorld = (class_3218) world;
                class_2338 origin = player.method_24515();
                boolean found = false;

                for (class_2338 p : class_2338.method_10097(origin.method_10069(-10, -10, -10), origin.method_10069(10, 10, 10))) {
                    class_2586 be = world.method_8321(p);
                    if (be instanceof class_2595 || be instanceof class_3719) {
                        found = true;
                        class_243 target = class_243.method_24953(p);
                        class_243 start = player.method_33571();
                        for (int i = 1; i <= 10; i++) {
                            double t = i / 10.0;
                            serverWorld.method_14199(class_2398.field_29643,
                                    start.field_1352 + (target.field_1352 - start.field_1352) * t,
                                    start.field_1351 + (target.field_1351 - start.field_1351) * t,
                                    start.field_1350 + (target.field_1350 - start.field_1350) * t,
                                    1, 0, 0, 0, 0.05);
                        }
                    }
                }

                player.method_7353(found
                        ? class_2561.method_43470("§aTreasure Sense: containers nearby!")
                        : class_2561.method_43470("§7No containers found within 10 blocks."), true);
                player.method_7357().method_7906(GOLDEN_AMETHYST, 200);
                player.method_7357().method_7906(VOID_CRYSTAL, 200);
            }
            return class_1269.field_5812;
        });

        // Kinetic Blink
        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 stack = player.method_5998(hand);
            if (!stack.method_31574(GOLDEN_AMETHYST) && !stack.method_31574(VOID_CRYSTAL)) return class_1271.method_22430(stack);
            if (player.method_5715() && !player.method_24828() && player.method_23318() >= -64.0) {
                if (!world.field_9236) {
                    class_243 look = player.method_5828(1.0f);
                    player.method_18799(look.method_1021(1.5));
                    player.field_6037 = true;
                    stack.method_7934(1);
                    player.method_7353(class_2561.method_43470("§6Kinetic Blink!"), true);
                }
                return class_1271.method_22427(stack);
            }
            return class_1271.method_22430(stack);
        });

        // Void escape
        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 stack = player.method_5998(hand);
            if (!stack.method_31574(VOID_CRYSTAL)) return class_1271.method_22430(stack);
            if (!world.field_9236 && player.method_23318() < -64.0) {
                double groundY = world.method_8624(net.minecraft.class_2902.class_2903.field_13203,
                        (int) player.method_23317(), (int) player.method_23321());
                player.method_6082(player.method_23317(), groundY, player.method_23321(), false);
                return class_1271.method_22427(stack);
            }
            return class_1271.method_22430(stack);
        });

        // Stasis Strike
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            class_1799 stack = player.method_5998(hand);
            if (!stack.method_31574(GOLDEN_AMETHYST) && !stack.method_31574(VOID_CRYSTAL)) return class_1269.field_5811;
            if (entity instanceof class_1309 living && !world.field_9236) {
                living.method_6092(new class_1293(class_1294.field_5909, 80, 9));
                living.method_6092(new class_1293(class_1294.field_5911, 80, 9));
                stack.method_7934(1);
                player.method_7353(class_2561.method_43470("§9Stasis Strike!"), true);
            }
            return class_1269.field_5811;
        });

        // Domain activation receiver
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.registerGlobalReceiver(
                ActivateDomainPayload.ID,
                (payload, context) -> {
                    net.minecraft.class_3222 player = context.player();
                    class_3218 world = (class_3218) player.method_37908();
                    UUID uid = player.method_5667();

                    if (domainCooldowns.containsKey(uid)) {
                        long elapsed = System.currentTimeMillis() - domainCooldowns.get(uid);
                        if (elapsed < 1800000) {
                            long remaining = (1800000 - elapsed) / 1000;
                            player.method_7353(class_2561.method_43470("§cDomain on cooldown! " + remaining + "s remaining"), true);
                            return;
                        }
                    }

                    if (domainTicks.containsKey(uid)) {
                        player.method_7353(class_2561.method_43470("§cDomain already active!"), true);
                        return;
                    }

                    java.util.List<class_2338> domeBlocks = new java.util.ArrayList<>();
                    int radius = 15;
                    class_2338 center = player.method_24515();

                    for (int x = -radius; x <= radius; x++) {
                        for (int y = -radius; y <= radius; y++) {
                            for (int z = -radius; z <= radius; z++) {
                                double dist = Math.sqrt(x * x + y * y + z * z);
                                if (dist >= radius - 0.5 && dist <= radius + 0.5) {
                                    class_2338 bp = center.method_10069(x, y, z);
                                    if (world.method_8320(bp).method_26215()) {
                                        world.method_8501(bp, net.minecraft.class_2246.field_22423.method_9564());
                                        domeBlocks.add(bp);
                                    }
                                }
                            }
                        }
                    }

                    activeDomes.put(uid, domeBlocks);
                    domainTicks.put(uid, 0);
                    world.method_14199(class_2398.field_11216, player.method_23317(), player.method_23318() + 1, player.method_23321(), 100, 5, 5, 5, 0.2);
                    player.method_7353(class_2561.method_43470("§5§lDomain Expansion: Void Realm!"), true);
                }
        );
    }

    public record StartCutscenePayload() implements net.minecraft.class_8710 {
        public static final net.minecraft.class_8710.class_9154<StartCutscenePayload> ID =
                new net.minecraft.class_8710.class_9154<>(class_2960.method_60655(MOD_ID, "start_cutscene"));
        public static final net.minecraft.class_9139<net.minecraft.class_2540, StartCutscenePayload> CODEC =
                net.minecraft.class_9139.method_56431(new StartCutscenePayload());
        @Override
        public net.minecraft.class_8710.class_9154<? extends net.minecraft.class_8710> method_56479() {
            return ID;
        }
    }

    public record ActivateDomainPayload() implements net.minecraft.class_8710 {
        public static final net.minecraft.class_8710.class_9154<ActivateDomainPayload> ID =
                new net.minecraft.class_8710.class_9154<>(class_2960.method_60655(MOD_ID, "activate_domain"));
        public static final net.minecraft.class_9139<net.minecraft.class_2540, ActivateDomainPayload> CODEC =
                net.minecraft.class_9139.method_56431(new ActivateDomainPayload());
        @Override
        public net.minecraft.class_8710.class_9154<? extends net.minecraft.class_8710> method_56479() {
            return ID;
        }
    }
}